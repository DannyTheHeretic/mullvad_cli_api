


class AccountNotFound(Exception):
    """The Account Wasn't Found"""