# A simple Python Based Mullvad Interface. 
------------------
Using commandline utils for interacting and using vpn
